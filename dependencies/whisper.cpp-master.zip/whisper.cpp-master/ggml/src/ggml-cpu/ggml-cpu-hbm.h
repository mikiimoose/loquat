#pragma once

#include "ggml-backend.h"
#include "ggml.h"

// GGML CPU internal header

ggml_backend_buffer_type_t ggml_backend_cpu_hbm_buffer_type(void);
